# Projeto: Cadastro de Veículos (CRUD - Padrão DAO)

## Resumo
Este é um projeto implementado para a disciplina, seguindo o padrão DAO e os requisitos do trabalho de projeto.
A entidade principal é **Veículo**, com mais de 10 atributos e operações CRUD: inserir, deletar, atualizar, consultar por id e listar todos.

## Atributos da entidade Veículo
- id
- marca
- modelo
- ano
- placa
- cor
- km
- combustivel
- status
- proprietario
- preco
- data_compra

(>= 10 atributos OK)

## Estrutura do projeto
- `index.php` - Roteador simples (chama o controller conforme `?acao=`)
- `controller/VeiculoController.php` - Métodos: listar, novo, editar, salvar, atualizar, deletar
- `dao/VeiculoDAO.php` - Implementa operações: criar, listar, buscarPorId, atualizar, deletar
- `model/Veiculo.php` - Classe modelo com getters/setters
- `view/veiculo_view.php` - Página de listagem
- `view/veiculo_form.php` - Formulário de cadastro/edição
- `view/apresentacao.php` - Página para apresentar nomes da dupla e checklist de requisitos
- `util/Conexao.php` - Conexão PDO com MySQL
- `sql/create_db.sql` - Script para criar o banco e inserir dados de exemplo
- `public/css/style.css` - Estilos da interface

## Como executar (ambiente local, ex.: USBWebserver)
1. Copie a pasta do projeto para o diretório do servidor local (ex: `www` do USBWebserver).
2. Abra o painel do servidor (USBWebserver) e inicie Apache + MySQL.
3. No phpMyAdmin, execute o script `sql/create_db.sql` para criar o banco `crud_veiculos` e popular exemplos.
4. Verifique/edite as credenciais em `util/Conexao.php` se necessário (usuário, senha, host, db).
5. Acesse no navegador: `http://localhost/[pasta_do_projeto]/index.php`.
6. Navegue e teste as operações: Novo, Editar, Deletar, Listar.

## Antes da apresentação
- Edite `view/apresentacao.php` e preencha o array `$componentes` com os nomes dos integrantes da dupla.
- Confirme que `util/Conexao.php` contém as credenciais corretas para o ambiente de laboratório.

## Conformidade com o enunciado
- a) Desenvolvido com padrões e temas estudados (DAO/MVC simplificado).
- b) Pode ser apresentado individualmente ou em dupla (arquivo `view/apresentacao.php` para identificar componentes).
- c) Entidade com >= 10 atributos (listados acima).
- d) Funcionalidades: inserir, deletar, atualizar, consultar por id, listar todos (implementadas no Controller/DAO).
- e) Ferramentas: testar em máquinas do laboratório (USBWebserver ou outro).

## Observações de segurança
- A senha `usbw` é comum em pacotes locais (ex.: USBWebserver) — altere para senhas fortes antes de expor o servidor.

## Arquivos a editar para personalizar
- `util/Conexao.php` — credenciais do banco
- `view/apresentacao.php` — nomes dos componentes

---