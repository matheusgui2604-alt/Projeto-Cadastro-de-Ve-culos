<?php
$titulo = isset($acao) && $acao == "atualizar" ? "Editar Veículo" : "Novo Veículo";
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $titulo; ?> - Cadastro de Veículos</title>
    <link rel="stylesheet" href="public/css/style.css?v=<?php echo time(); ?>">
</head>
<body>
    <header>
        <div class="header-content">
            <h1>Cadastro de Veículos</h1>
            <div style="display:flex; align-items:center; gap:12px;">
                <div class="breadcrumb">
                    <a href="index.php?acao=listar" style="color: #667eea; text-decoration: none;">Dashboard</a> / 
                    <a href="index.php?acao=listar" style="color: #667eea; text-decoration: none;">Veículos</a> / 
                    <span><?php echo $titulo; ?></span>
                </div>
                <a href="index.php?acao=apresentacao" class="btn btn-secondary" style="margin-left:12px;">📋 Apresentação</a>
            </div>
        </div>
    </header>

    <div class="container">
        <div class="section-header">
            <h2><?php echo $titulo; ?></h2>
        </div>

        <div class="form-container">
            <form method="POST" action="index.php?acao=<?php echo $acao; ?>">
                <?php if ($veiculo != null) { ?>
                    <input type="hidden" name="id" value="<?php echo $veiculo['id']; ?>">
                <?php } ?>

                <div class="form-grid">
                    <div class="form-group">
                        <label for="marca">Marca do Veículo *</label>
                        <input type="text" id="marca" name="marca" placeholder="Ex: Toyota" required value="<?php echo htmlspecialchars($veiculo['marca'] ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label for="modelo">Modelo *</label>
                        <input type="text" id="modelo" name="modelo" placeholder="Ex: Corolla" required value="<?php echo htmlspecialchars($veiculo['modelo'] ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label for="ano">Ano de Fabricação *</label>
                        <input type="number" id="ano" name="ano" placeholder="2024" min="1900" max="<?php echo date('Y') + 1; ?>" required value="<?php echo $veiculo['ano'] ?? ''; ?>">
                    </div>

                    <div class="form-group">
                        <label for="placa">Placa do Veículo *</label>
                        <input type="text" id="placa" name="placa" placeholder="ABC-1234" required value="<?php echo htmlspecialchars($veiculo['placa'] ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label for="cor">Cor *</label>
                        <select id="cor" name="cor" required>
                            <option value="">Selecione uma cor</option>
                            <option value="Branco" <?php echo ($veiculo['cor'] ?? '') == 'Branco' ? 'selected' : ''; ?>>Branco</option>
                            <option value="Preto" <?php echo ($veiculo['cor'] ?? '') == 'Preto' ? 'selected' : ''; ?>>Preto</option>
                            <option value="Vermelho" <?php echo ($veiculo['cor'] ?? '') == 'Vermelho' ? 'selected' : ''; ?>>Vermelho</option>
                            <option value="Azul" <?php echo ($veiculo['cor'] ?? '') == 'Azul' ? 'selected' : ''; ?>>Azul</option>
                            <option value="Prata" <?php echo ($veiculo['cor'] ?? '') == 'Prata' ? 'selected' : ''; ?>>Prata</option>
                            <option value="Cinza" <?php echo ($veiculo['cor'] ?? '') == 'Cinza' ? 'selected' : ''; ?>>Cinza</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="km">Quilometragem (KM) *</label>
                        <input type="number" id="km" name="km" placeholder="0" min="0" required value="<?php echo $veiculo['km'] ?? ''; ?>">
                    </div>

                    <div class="form-group">
                        <label for="combustivel">Tipo de Combustível *</label>
                        <select id="combustivel" name="combustivel" required>
                            <option value="">Selecione um combustível</option>
                            <option value="Gasolina" <?php echo ($veiculo['combustivel'] ?? '') == 'Gasolina' ? 'selected' : ''; ?>>Gasolina</option>
                            <option value="Diesel" <?php echo ($veiculo['combustivel'] ?? '') == 'Diesel' ? 'selected' : ''; ?>>Diesel</option>
                            <option value="Álcool" <?php echo ($veiculo['combustivel'] ?? '') == 'Álcool' ? 'selected' : ''; ?>>Álcool</option>
                            <option value="Híbrido" <?php echo ($veiculo['combustivel'] ?? '') == 'Híbrido' ? 'selected' : ''; ?>>Híbrido</option>
                            <option value="Elétrico" <?php echo ($veiculo['combustivel'] ?? '') == 'Elétrico' ? 'selected' : ''; ?>>Elétrico</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="status">Status do Veículo *</label>
                        <select id="status" name="status" required>
                            <option value="">Selecione um status</option>
                            <option value="Disponível" <?php echo ($veiculo['status'] ?? '') == 'Disponível' ? 'selected' : ''; ?>>Disponível</option>
                            <option value="Alugado" <?php echo ($veiculo['status'] ?? '') == 'Alugado' ? 'selected' : ''; ?>>Alugado</option>
                            <option value="Manutenção" <?php echo ($veiculo['status'] ?? '') == 'Manutenção' ? 'selected' : ''; ?>>Manutenção</option>
                            <option value="Indisponível" <?php echo ($veiculo['status'] ?? '') == 'Indisponível' ? 'selected' : ''; ?>>Indisponível</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="proprietario">Nome do Proprietário *</label>
                        <input type="text" id="proprietario" name="proprietario" placeholder="Ex: João Silva" required value="<?php echo htmlspecialchars($veiculo['proprietario'] ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label for="preco">Preço (R$) *</label>
                        <input type="number" id="preco" name="preco" placeholder="0,00" step="0.01" min="0" required value="<?php echo $veiculo['preco'] ?? ''; ?>">
                    </div>

                    <div class="form-group">
                        <label for="data_compra">Data de Compra *</label>
                        <input type="date" id="data_compra" name="data_compra" required value="<?php echo $veiculo['data_compra'] ?? ''; ?>">
                    </div>
                </div>

                <div class="form-buttons">
                    <button type="submit" class="btn btn-primary" style="flex: 0 0 auto;">
                        <?php echo $acao == "atualizar" ? "💾 Atualizar Veículo" : "➕ Cadastrar Veículo"; ?>
                    </button>
                    <a href="index.php?acao=listar" class="btn btn-secondary" style="flex: 0 0 auto;">❌ Cancelar</a>
                </div>

                <p style="margin-top: 20px; color: #999; font-size: 12px;">* Campos obrigatórios</p>
            </form>
        </div>
    </div>

    <footer>
        <p>© 2025 Sistema de Cadastro de Veículos - Todos os direitos reservados</p>
    </footer>
</body>
</html>
