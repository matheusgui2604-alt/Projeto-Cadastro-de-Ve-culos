<?php
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Veículos</title>
    <link rel="stylesheet" href="public/css/style.css?v=<?php echo time(); ?>"
</head>
<body>
    <header>
        <div class="header-content">
            <h1>Cadastro de Veículos</h1>
            <div style="display:flex; align-items:center; gap:12px;">
                <div class="breadcrumb">Dashboard / <span>Veículos</span></div>
                <a href="index.php?acao=apresentacao" class="btn btn-secondary" style="margin-left:12px;">📋 Apresentação</a>
            </div>
        </div>
    </header>

    <div class="container">
        <?php
        if (isset($_SESSION["mensagem"])) {
            $tipo = $_SESSION["tipo_mensagem"];
            $classe = $tipo == "sucesso" ? "alert-success" : "alert-error";
            echo "<div class='alert {$classe}'>" . $_SESSION["mensagem"] . "</div>";
            unset($_SESSION["mensagem"]);
            unset($_SESSION["tipo_mensagem"]);
        }
        ?>

        <div class="section-header">
            <h2>Lista de Veículos</h2>
            <a href="index.php?acao=novo" class="btn btn-primary">+ Adicionar Novo Veículo</a>
        </div>

        <?php if (!empty($veiculos)) { ?>
            <div class="table-wrapper">
                <table class="tabela">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Marca</th>
                            <th>Modelo</th>
                            <th>Ano</th>
                            <th>Placa</th>
                            <th>Cor</th>
                            <th>KM</th>
                            <th>Combustível</th>
                            <th>Status</th>
                            <th>Proprietário</th>
                            <th>Preço</th>
                            <th>Data Compra</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($veiculos as $veiculo) { ?>
                            <tr>
                                <td><strong>#<?php echo $veiculo['id']; ?></strong></td>
                                <td><?php echo htmlspecialchars($veiculo['marca']); ?></td>
                                <td><?php echo htmlspecialchars($veiculo['modelo']); ?></td>
                                <td><?php echo $veiculo['ano']; ?></td>
                                <td><strong><?php echo $veiculo['placa']; ?></strong></td>
                                <td>
                                    <span style="display: inline-block; width: 24px; height: 24px; background-color: <?php 
                                        $cores = [
                                            'Branco' => '#FFFFFF',
                                            'Preto' => '#000000',
                                            'Vermelho' => '#FF0000',
                                            'Azul' => '#0000FF',
                                            'Prata' => '#C0C0C0',
                                            'Cinza' => '#808080'
                                        ];
                                        echo $cores[$veiculo['cor']] ?? '#999999';
                                    ?>; border: 1px solid #ddd; border-radius: 4px; vertical-align: middle;"></span>
                                    <?php echo htmlspecialchars($veiculo['cor']); ?>
                                </td>
                                <td><?php echo number_format($veiculo['km'], 0, ',', '.'); ?> km</td>
                                <td><?php echo htmlspecialchars($veiculo['combustivel']); ?></td>
                                <td>
                                    <span class="status status-<?php echo strtolower(str_replace(' ', '-', $veiculo['status'])); ?>">
                                        <?php echo $veiculo['status']; ?>
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars($veiculo['proprietario']); ?></td>
                                <td><span class="valor">R$ <?php echo number_format($veiculo['preco'], 2, ',', '.'); ?></span></td>
                                <td><span class="data"><?php echo date('d/m/Y', strtotime($veiculo['data_compra'])); ?></span></td>
                                <td class="acoes-coluna">
                                    <a href="index.php?acao=editar&id=<?php echo $veiculo['id']; ?>" class="btn btn-small btn-warning">✏️ Editar</a>
                                    <a href="index.php?acao=deletar&id=<?php echo $veiculo['id']; ?>" class="btn btn-small btn-danger" onclick="return confirm('⚠️ Tem certeza que deseja deletar este veículo? Esta ação não pode ser desfeita.');">🗑️ Deletar</a>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>

            <footer>
                <p>📊 Total de Veículos: <strong><?php echo count($veiculos); ?></strong></p>
            </footer>
        <?php } else { ?>
            <div class="mensagem-vazia">
                <p>Nenhum veículo cadastrado no sistema</p>
                <a href="index.php?acao=novo">Cadastre o primeiro veículo agora</a>
            </div>
        <?php } ?>
    </div>

    <footer>
        <p>© 2025 Sistema de Cadastro de Veículos - Todos os direitos reservados</p>
    </footer>
</body>
</html>
