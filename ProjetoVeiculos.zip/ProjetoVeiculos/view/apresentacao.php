<?php
// Insira os nomes dos componentes da dupla ou individual aqui
$componentes = [
    'Matheus Guilherme Rodrigues da Silva',
    'Gustavo Triboni'
];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Apresentação - Cadastro de Veículos</title>
    <link rel="stylesheet" href="public/css/style.css?v=<?php echo time(); ?>"
</head>
<body>
    <header>
        <div class="header-content">
            <h1>Apresentação do Projeto</h1>
            <div>
                <div class="breadcrumb">Dashboard / <span>Apresentação</span></div>
                <a href="index.php?acao=listar" class="btn btn-primary" style="margin-left:15px;">🔙 Voltar</a>
            </div>
        </div>
    </header>

    <div class="container">
        <div class="section-header">
            <h2>Informações do Projeto</h2>
        </div>

        <div class="form-container">
            <h3>Componentes</h3>
            <ul>
                <?php foreach ($componentes as $c) { echo '<li>' . htmlspecialchars($c) . '</li>'; } ?>
            </ul>

            <h3>Descrição</h3>
            <p>Este projeto implementa um CRUD (inserir, deletar, atualizar, consultar por id e listar todos) para cadastro de veículos, utilizando o padrão DAO, conforme orientações da disciplina.</p>

            <h3>Requisitos atendidos</h3>
            <ul>
                <li>Entidade: <strong>Veículo</strong></li>
                <li>Atributos (>= 10): <strong>id, marca, modelo, ano, placa, cor, km, combustivel, status, proprietario, preco, data_compra</strong></li>
                <li>Operações implementadas: inserir, deletar, atualizar, consultar por id, listar todos</li>
                <li>Arquitetura: Model / DAO / Controller / View (padrão MVC simples)</li>
            </ul>
            <h3>Tecnologias utilizadas</h3>
            <ul>
                <li>PHP para backend</li>
                <li>MySQL para banco de dados</li>
                <li>HTML/CSS para frontend</li>