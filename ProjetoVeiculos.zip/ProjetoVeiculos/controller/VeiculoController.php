<?php
require_once "dao/VeiculoDAO.php";
require_once "model/Veiculo.php";

class VeiculoController {
    private $dao;

    public function __construct() {
        $this->dao = new VeiculoDAO();
    }

    // Listar todos os veículos
    public function listar() {
        $veiculos = $this->dao->listar();
        include "view/veiculo_view.php";
    }

    // Exibir formulário para novo veículo
    public function novo() {
        $veiculo = null;
        $acao = "salvar";
        include "view/veiculo_form.php";
    }

    // Exibir formulário para editar veículo
    public function editar() {
        $id = $_GET["id"];
        $veiculo = $this->dao->buscarPorId($id);
        $acao = "atualizar";
        include "view/veiculo_form.php";
    }

    // Salvar novo veículo
    public function salvar() {
        $veiculo = new Veiculo();
        $veiculo->setMarca($_POST["marca"]);
        $veiculo->setModelo($_POST["modelo"]);
        $veiculo->setAno($_POST["ano"]);
        $veiculo->setPlaca($_POST["placa"]);
        $veiculo->setCor($_POST["cor"]);
        $veiculo->setKm($_POST["km"]);
        $veiculo->setCombustivel($_POST["combustivel"]);
        $veiculo->setStatus($_POST["status"]);
        $veiculo->setProprietario($_POST["proprietario"]);
        $veiculo->setPreco($_POST["preco"]);
        $veiculo->setDataCompra($_POST["data_compra"]);

        if ($this->dao->criar($veiculo)) {
            $_SESSION["mensagem"] = "Veículo cadastrado com sucesso!";
            $_SESSION["tipo_mensagem"] = "sucesso";
        } else {
            $_SESSION["mensagem"] = "Erro ao cadastrar veículo!";
            $_SESSION["tipo_mensagem"] = "erro";
        }
        header("Location: index.php?acao=listar");
        exit;
    }

    // Atualizar veículo existente
    public function atualizar() {
        $veiculo = new Veiculo();
        $veiculo->setId($_POST["id"]);
        $veiculo->setMarca($_POST["marca"]);
        $veiculo->setModelo($_POST["modelo"]);
        $veiculo->setAno($_POST["ano"]);
        $veiculo->setPlaca($_POST["placa"]);
        $veiculo->setCor($_POST["cor"]);
        $veiculo->setKm($_POST["km"]);
        $veiculo->setCombustivel($_POST["combustivel"]);
        $veiculo->setStatus($_POST["status"]);
        $veiculo->setProprietario($_POST["proprietario"]);
        $veiculo->setPreco($_POST["preco"]);
        $veiculo->setDataCompra($_POST["data_compra"]);

        if ($this->dao->atualizar($veiculo)) {
            $_SESSION["mensagem"] = "Veículo atualizado com sucesso!";
            $_SESSION["tipo_mensagem"] = "sucesso";
        } else {
            $_SESSION["mensagem"] = "Erro ao atualizar veículo!";
            $_SESSION["tipo_mensagem"] = "erro";
        }
        header("Location: index.php?acao=listar");
        exit;
    }

    // Deletar veículo
    public function deletar() {
        $id = $_GET["id"];
        if ($this->dao->deletar($id)) {
            $_SESSION["mensagem"] = "Veículo deletado com sucesso!";
            $_SESSION["tipo_mensagem"] = "sucesso";
        } else {
            $_SESSION["mensagem"] = "Erro ao deletar veículo!";
            $_SESSION["tipo_mensagem"] = "erro";
        }
        header("Location: index.php?acao=listar");
        exit;
    }

    // Página de apresentação com nomes da dupla e checklist
    public function apresentacao() {
        include "view/apresentacao.php";
    }
}
