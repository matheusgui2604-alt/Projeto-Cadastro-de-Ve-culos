<?php
class Conexao {
    private static $host = "localhost";
    private static $db = "crud_veiculos";
    private static $user = "matheus";
    private static $password = "2604";
    private static $pdo;

    public static function conectar() {
        if (self::$pdo == null) {
            try {
                // Use charset in DSN to avoid encoding issues
                $dsn = "mysql:host=" . self::$host . ";dbname=" . self::$db . ";charset=utf8mb4";
                self::$pdo = new PDO($dsn, self::$user, self::$password, [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                ]);
            } catch (PDOException $e) {
                // Se for erro de credenciais (acesso negado), tente fallback comum (senha vazia) — útil para XAMPP
                $msg = $e->getMessage();
                $code = $e->getCode();
                if ((string)$code === '1045' || stripos($msg, 'Access denied') !== false) {
                    // tenta conectar sem senha (XAMPP padrão)
                    try {
                        $dsn = "mysql:host=" . self::$host . ";dbname=" . self::$db . ";charset=utf8mb4";
                        self::$pdo = new PDO($dsn, self::$user, '', [
                            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                        ]);
                        echo "Conectado usando senha vazia (fallback). Atualize 'util/Conexao.php' com as credenciais corretas para evitar este aviso.";
                    } catch (PDOException $e2) {
                        echo "Erro na conexão ao tentar fallback (senha vazia): " . $e2->getMessage();
                        echo "\nDicas: verifique as credenciais em 'util/Conexao.php' e confirme o usuário/senha no phpMyAdmin do XAMPP.";
                        exit;
                    }
                } else {
                    echo "Erro na conexão: " . $msg;
                    exit;
                }
            }
        }
        return self::$pdo;
    }
}
