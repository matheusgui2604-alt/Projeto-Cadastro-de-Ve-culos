-- Criar banco de dados
CREATE DATABASE IF NOT EXISTS crud_veiculos;
USE crud_veiculos;

-- Criar tabela de veículos
CREATE TABLE IF NOT EXISTS veiculo (
    id INT AUTO_INCREMENT PRIMARY KEY,
    marca VARCHAR(100) NOT NULL,
    modelo VARCHAR(100) NOT NULL,
    ano INT NOT NULL,
    placa VARCHAR(10) NOT NULL UNIQUE,
    cor VARCHAR(50) NOT NULL,
    km INT NOT NULL DEFAULT 0,
    combustivel VARCHAR(50) NOT NULL,
    status VARCHAR(50) NOT NULL,
    proprietario VARCHAR(150) NOT NULL,
    preco DECIMAL(10, 2) NOT NULL,
    data_compra DATE NOT NULL,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Inserir alguns dados de exemplo
INSERT INTO veiculo (marca, modelo, ano, placa, cor, km, combustivel, status, proprietario, preco, data_compra) VALUES
('Toyota', 'Corolla', 2022, 'ABC-1234', 'Branco', 15000, 'Gasolina', 'Disponível', 'João Silva', 85000.00, '2022-03-15'),
('Honda', 'Civic', 2021, 'XYZ-5678', 'Preto', 25000, 'Gasolina', 'Alugado', 'Maria Santos', 95000.00, '2021-06-20'),
('Volkswagen', 'Gol', 2020, 'DEF-9012', 'Vermelho', 35000, 'Gasolina', 'Disponível', 'Pedro Oliveira', 55000.00, '2020-11-10'),
('Fiat', 'Uno', 2019, 'GHI-3456', 'Azul', 45000, 'Gasolina', 'Manutenção', 'Ana Costa', 42000.00, '2019-05-08');
