<?php
session_start();
require_once "controller/VeiculoController.php";

$controller = new VeiculoController();

// Ações permitidas — mantenha em sincronia com os métodos públicos do controller
$allowedActions = ['listar', 'novo', 'editar', 'salvar', 'atualizar', 'deletar', 'apresentacao'];

// Recupera e sanitiza o parâmetro 'acao'
$acao = filter_input(INPUT_GET, 'acao', FILTER_SANITIZE_STRING);
if (empty($acao)) {
    $acao = 'listar';
} else {
    // Permitir somente letras e underscore (evita caracteres perigosos)
    $acao = preg_replace('/[^a-zA-Z_]/', '', $acao);
}

// Executa a ação somente se estiver na whitelist e existir no controller
if (in_array($acao, $allowedActions, true) && method_exists($controller, $acao)) {
    $controller->$acao();
} else {
    // Ação inválida ou não autorizada: redireciona para a listagem
    $controller->listar();
}
