<?php
class Veiculo {
    private $id;
    private $marca;
    private $modelo;
    private $ano;
    private $placa;
    private $cor;
    private $km;
    private $combustivel;
    private $status;
    private $proprietario;
    private $preco;
    private $data_compra;

    public function __construct() {}

    // Getters e Setters
    public function getId() {
        return $this->id;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function getMarca() {
        return $this->marca;
    }

    public function setMarca($marca) {
        $this->marca = $marca;
    }

    public function getModelo() {
        return $this->modelo;
    }

    public function setModelo($modelo) {
        $this->modelo = $modelo;
    }

    public function getAno() {
        return $this->ano;
    }

    public function setAno($ano) {
        $this->ano = $ano;
    }

    public function getPlaca() {
        return $this->placa;
    }

    public function setPlaca($placa) {
        $this->placa = $placa;
    }

    public function getCor() {
        return $this->cor;
    }

    public function setCor($cor) {
        $this->cor = $cor;
    }

    public function getKm() {
        return $this->km;
    }

    public function setKm($km) {
        $this->km = $km;
    }

    public function getCombustivel() {
        return $this->combustivel;
    }

    public function setCombustivel($combustivel) {
        $this->combustivel = $combustivel;
    }

    public function getStatus() {
        return $this->status;
    }

    public function setStatus($status) {
        $this->status = $status;
    }

    public function getProprietario() {
        return $this->proprietario;
    }

    public function setProprietario($proprietario) {
        $this->proprietario = $proprietario;
    }

    public function getPreco() {
        return $this->preco;
    }

    public function setPreco($preco) {
        $this->preco = $preco;
    }

    public function getDataCompra() {
        return $this->data_compra;
    }

    public function setDataCompra($data_compra) {
        $this->data_compra = $data_compra;
    }
}
