<?php
require_once "util/Conexao.php";
require_once "model/Veiculo.php";

class VeiculoDAO {
    private $conexao;

    public function __construct() {
        $this->conexao = Conexao::conectar();
    }

    // CREATE - Inserir novo veículo
    public function criar(Veiculo $veiculo) {
        try {
            $sql = "INSERT INTO veiculo (marca, modelo, ano, placa, cor, km, combustivel, status, proprietario, preco, data_compra) 
                    VALUES (:marca, :modelo, :ano, :placa, :cor, :km, :combustivel, :status, :proprietario, :preco, :data_compra)";
            
            $stmt = $this->conexao->prepare($sql);
            $stmt->bindValue(":marca", $veiculo->getMarca());
            $stmt->bindValue(":modelo", $veiculo->getModelo());
            $stmt->bindValue(":ano", $veiculo->getAno());
            $stmt->bindValue(":placa", $veiculo->getPlaca());
            $stmt->bindValue(":cor", $veiculo->getCor());
            $stmt->bindValue(":km", $veiculo->getKm());
            $stmt->bindValue(":combustivel", $veiculo->getCombustivel());
            $stmt->bindValue(":status", $veiculo->getStatus());
            $stmt->bindValue(":proprietario", $veiculo->getProprietario());
            $stmt->bindValue(":preco", $veiculo->getPreco());
            $stmt->bindValue(":data_compra", $veiculo->getDataCompra());
            
            return $stmt->execute();
        } catch (Exception $e) {
            echo "Erro ao criar veículo: " . $e->getMessage();
            return false;
        }
    }

    // READ - Listar todos os veículos
    public function listar() {
        try {
            $sql = "SELECT * FROM veiculo";
            $stmt = $this->conexao->prepare($sql);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            echo "Erro ao listar veículos: " . $e->getMessage();
            return [];
        }
    }

    // READ - Buscar veículo por ID
    public function buscarPorId($id) {
        try {
            $sql = "SELECT * FROM veiculo WHERE id = :id";
            $stmt = $this->conexao->prepare($sql);
            $stmt->bindValue(":id", $id);
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            echo "Erro ao buscar veículo: " . $e->getMessage();
            return null;
        }
    }

    // UPDATE - Atualizar veículo
    public function atualizar(Veiculo $veiculo) {
        try {
            $sql = "UPDATE veiculo SET marca = :marca, modelo = :modelo, ano = :ano, placa = :placa, 
                    cor = :cor, km = :km, combustivel = :combustivel, status = :status, proprietario = :proprietario,
                    preco = :preco, data_compra = :data_compra
                    WHERE id = :id";
            
            $stmt = $this->conexao->prepare($sql);
            $stmt->bindValue(":id", $veiculo->getId());
            $stmt->bindValue(":marca", $veiculo->getMarca());
            $stmt->bindValue(":modelo", $veiculo->getModelo());
            $stmt->bindValue(":ano", $veiculo->getAno());
            $stmt->bindValue(":placa", $veiculo->getPlaca());
            $stmt->bindValue(":cor", $veiculo->getCor());
            $stmt->bindValue(":km", $veiculo->getKm());
            $stmt->bindValue(":combustivel", $veiculo->getCombustivel());
            $stmt->bindValue(":status", $veiculo->getStatus());
            $stmt->bindValue(":proprietario", $veiculo->getProprietario());
            $stmt->bindValue(":preco", $veiculo->getPreco());
            $stmt->bindValue(":data_compra", $veiculo->getDataCompra());
            
            return $stmt->execute();
        } catch (Exception $e) {
            echo "Erro ao atualizar veículo: " . $e->getMessage();
            return false;
        }
    }

    // DELETE - Deletar veículo
    public function deletar($id) {
        try {
            $sql = "DELETE FROM veiculo WHERE id = :id";
            $stmt = $this->conexao->prepare($sql);
            $stmt->bindValue(":id", $id);
            return $stmt->execute();
        } catch (Exception $e) {
            echo "Erro ao deletar veículo: " . $e->getMessage();
            return false;
        }
    }
}
